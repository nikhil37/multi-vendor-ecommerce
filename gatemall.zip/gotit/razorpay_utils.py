import razorpay
from pdb import set_trace
order_id = "order_IML2S9zt6W23mD"
client = razorpay.Client(auth = ("rzp_test_SYDBz37zUbb6w5","qCpxag0Y6UR9Q7aj7Qm1gby5"))

def make_order(user):
	DATA = {
	"amount": 100,
	"currency": "INR",
	"receipt": "receipt#1",
	"notes": {
		"key1": "value3",
		"key2": "value2"
		}
	}
	x = client.order.create(data=DATA)


def order_fetch(user):
	resp = client.order.fetch(order_id)
	set_trace()


order_fetch("testing")