from django.apps import AppConfig


class GotitConfig(AppConfig):
    name = 'gotit'
